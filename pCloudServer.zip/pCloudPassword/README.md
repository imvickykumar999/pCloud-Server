
# Steps to Run:

python3 -m venv venv

## On Ubuntu, use: 
source venv/bin/activate  

## On Windows, use: 
venv\Scripts\activate

pip install -r requirements.txt

python3 app.py

